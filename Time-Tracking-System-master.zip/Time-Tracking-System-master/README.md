# Time-Tracking-System

 GANZO
 
 
Login
✔️ Show current date & time
✔️ Create Admin User
✔️ Can Login

Home (Admin)
✔️ List all Users
✔️ Create/Update/Delete User
✔️Delete any User time log

Home (Normal)
✔️Time in/Time out
